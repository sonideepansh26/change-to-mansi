package Assignment_2_Exs_04;
public class Account { 
	private long accnum;
	private double balance;
	private Person accholder; //a person type variable i.e. accholder will hold the address of where the obj is really stored
	
	
	
	
	public long getAccnum() {
		return accnum;
	}
	public void setAccnum(long accnum) {
		this.accnum = accnum;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public Person getAccholder() {
		return accholder;
	}
	public void setAccholder(Person accholder) {
		this.accholder = accholder;
	}
	
	public void deposit(double amt){
	balance = balance+ amt;
    }
	
	public boolean withDraw(double amt){

		balance= balance-amt;
		return true;
		
	}
	public Account(long accnum, double balance) {
		super();
		this.accnum = accnum;
		this.balance = balance;
	}}
	
	

