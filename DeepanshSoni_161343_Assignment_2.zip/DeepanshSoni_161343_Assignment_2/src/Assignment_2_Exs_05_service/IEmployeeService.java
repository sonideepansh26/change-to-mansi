package Assignment_2_Exs_05_service;

import Assignment_2_Exs_05_Bean.Employee;


	public interface IEmployeeService{
		

		//String getInsuranceScheme();

	

 public	String getInsuranceScheme(Employee emp);
	

}
