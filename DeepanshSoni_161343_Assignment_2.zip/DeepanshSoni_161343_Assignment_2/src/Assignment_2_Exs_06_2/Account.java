package Assignment_2_Exs_06_2;

	public class Account {
		private long accNo;
		private double balance;
		private Person accHolder;
		public long getAccNo() {
			return accNo;
		}
		public void setAccNo(long accNo) {
			this.accNo = accNo;
		}
		public double getBalance() {
			return balance;
		}
		public void setBalance(double balance) {
			this.balance = balance;
		}
		public Person getAccHolder() {
			return accHolder;
		}
		public void setAccHolder(Person accHolder) {
			this.accHolder = accHolder;
		}
		public void deposit(double m)
		{
			this.balance = this.balance+2000;
		}
		public void withdraw(double w)
		{
			this.balance = this.balance-2000;
		}
		public void getbalance()
		{
			//System.out.println("balance in "+accHolder+"is :"+balance);
		}
		public String toString()
		{
			return "balance in " +" is :"+balance;
			
		}
		
		public class Savings_Account extends Account
		{
			final float mini_bal = (float) balance;
			public void withdraw(int w)
			{
				if(mini_bal>w)
				{
					balance = balance-w;
					System.out.println(balance);
				}
			}
		}
		public class Current_Account extends Account
		{
			final float overdraft_limit = 1000;
			public boolean withdraw(){
			
				if(balance <= overdraft_limit)
				
					return true;
				
			//if(balance > overdraft_limit)
				else
					return false;
				
				
			}
			
		}
		
	}


