package Assignment_2_Exs_11.service;

import java.util.List;

import Assignment_2_Exs_11_Bean.Mobiles;
import Assignment_2_Exs_11_Bean.PurchaseDetails;
import Assignment_2_Exs_11_exception.MobileException;

public interface IMobileService {

	
	public PurchaseDetails addDetails(PurchaseDetails purchase) throws MobileException;
	public Mobiles updateDetails(int quantity, int mobileId) throws MobileException;
	public List<Mobiles> getMobileList() throws MobileException;
	public Mobiles deleteDetails(int mobileId) throws MobileException;
	public List<Mobiles> inBetween(int min, int max) throws MobileException;
	public boolean validateDetails(PurchaseDetails purchase) throws MobileException ;
	
}
