package Assignment_2_Exs_12_0Bean;
import org.apache.log4j.Logger;

public class Message {
      static Logger logger=Logger.getLogger(Message.class);
      private String msg;
      
	
    
	public static Logger getLogger() {
		return logger;
	}

	public String getMessage() {
		logger.info("This is my info  msg");
		logger.debug("This is my debug message");
		logger.error("This is my error message");
		logger.warn("This is my warn message");
		logger.fatal("This is my fatal message");
		
		return msg;
	}

	public static void setLogger(Logger logger) {
		Message.logger = logger;
	}

	public void setMessage(String msg) {
		this.msg = msg;
		logger.info("This is my info  msg");
		logger.debug("This is my debug message");
		logger.error("This is my error message");
		logger.warn("This is my warn message");
		logger.fatal("This is my fatal message");
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	

}
