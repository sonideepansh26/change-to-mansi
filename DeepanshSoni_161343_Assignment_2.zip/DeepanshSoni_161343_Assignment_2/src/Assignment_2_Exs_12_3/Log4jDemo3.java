package Assignment_2_Exs_12_3;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import Assignment_2_Exs_12_0Bean.Message;

public class Log4jDemo3 {
    static Logger logger=Logger.getLogger(Log4jDemo3.class);
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PropertyConfigurator.configure("log4j.properties");
      Message m=new Message();
      m.setMessage(null);
      
     
      System.out.println(m.getMessage());
      logger.info("This is info level msg");
		logger.debug("This is debug level message");
		logger.error("This is error level message");
		logger.warn("This is warn level message");
		logger.fatal("This is fatal level message");
		
		System.out.println("messages logged to file :basic.log");
   
      
	}

}
